export TEXTIMG_FONT_FILE=/Library/Fonts/VL-Gothic-Regular.ttf
export TEXTIMG_EMOJI_DIR=/usr/local/src/noto-emoji/png/128
export RUNEWIDTH_EASTASIAN=1