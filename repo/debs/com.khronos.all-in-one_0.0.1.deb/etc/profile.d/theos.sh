export THEOS="$HOME/theos"
export PATH="$PATH:$THEOS/bin"