clip(){
  clipme "$(cat)"
}

filza(){
  if [ "$#" -ge 1 ]; then
    case "${1::1}" in
      "/") uiopen "filza://${1}";;
      *) uiopen "filza://$(pwd)/${1}";;
    esac
  else
    uiopen filza://
  fi
}

#sed -i 's/^[^#]/# &/' $HOME/.bash_history

alias l='ls -CF'
alias la='ls -A'
alias ll='ls -alF'
