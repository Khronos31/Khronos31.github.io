# Khronos

# export TMPDIR=/usr/tmp
export CC=clang
export CXX=clang++
export AR=llvm-ar